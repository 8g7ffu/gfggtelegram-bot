#!/bin/bash
python reveal_watcher.py &
gunicorn app:app --bind 0.0.0.0:$PORT
